#include<stdio.h>
#include<math.h>

void main()
{ double x,y;
printf("Enter x and y: ");
scanf("%lf%lf",&x,&y);


printf("%0.2f",fabs((x-y)));

}
