#include<stdio.h>
void draw_d(void);
void draw_o(void);
void draw_l(void);

int main()
{



draw_d();
draw_o();
draw_l();
draw_l();



}



void draw_d(void)
{
printf("***    \n");
printf("*   *    \n");
printf("*    *   \n");
printf("*   *  \n");
printf("*** \n");
}



void draw_l(void)
{
printf("*         \n");
printf("*         \n");
printf("*         \n");
printf("*         \n");
printf("*******   \n");
}

void draw_o(void)
{
printf("  * *     \n");
printf("*     *  \n");
printf("*     *  \n");
printf("  * *    \n");
}
