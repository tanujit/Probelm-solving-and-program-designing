#include<stdio.h>
void convert(double);
void display(double);


int main()
{
double miles;
printf("Enter miles: ");
scanf("%lf",&miles);

convert( miles);

}



void convert(double miles)
{
display ((1.609*miles));
}



void display(double kms)
{
printf("Kilometres= %f\n",kms);

}


