#include<stdio.h>
void draw_base(void);
void draw_intersection(void);
void draw_parallel_lines(void);
void draw_circle(void);
void draw_triangle(void);
int 
main(void)
{

draw_triangle();

printf("\n\n\n");

draw_base();
draw_parallel_lines();
draw_base();
}
void draw_triangle(void)
{
draw_intersection();
draw_base();
}
void draw_intersection(void)
{
printf("     *     \n");
printf("    * *    \n");
printf("   *   *   \n");
printf("  *     *  \n");
printf(" *       * \n");
}
void draw_base(void)
{
printf("***********\n");
}
void draw_parallel_lines(void)
{
printf("*         *\n");
printf("*         *\n");
printf("*         *\n");


}
