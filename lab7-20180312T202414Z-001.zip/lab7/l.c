
#include<stdio.h>


main()
{
int count ,i,n,sum=0;
printf("Enter n: ");
scanf("%d",&n);


i=0;
while (i <= n)
{
sum+=i;

i++;
}
double sum1=(n*(n+1))/2.0;


if(sum1==sum)
printf("Equal");
else
printf("not equal");

}
