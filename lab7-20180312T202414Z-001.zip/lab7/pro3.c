#include<stdio.h>
#include<math.h>
main()
{
int n=6,i=0;
while (i <= n)
{
 printf("%d   %2.0f\n",i,pow(2,i));
 i++;
}

printf("\n");

}
