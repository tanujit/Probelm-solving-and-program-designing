#include <stdio.h>
int
main(void)
{
int sum = 0,score,input_status;

printf("Scores\n");
input_status = scanf("%d",&score);

while (input_status ==1)
{
printf("%5d\n", score);
sum += score;
input_status = scanf("%d", &score);
}


printf("\nSum of exam scores is %d\n", sum);

return (0);
}
