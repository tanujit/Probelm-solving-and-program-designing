#include<stdio.h>

main()
{
int n, ev=0;
scanf("%d", &n);
ev = 0;
while (ev < n)
{
 printf("%3d", ev);
 ev = ev + 2;
}

printf("\n");

}
