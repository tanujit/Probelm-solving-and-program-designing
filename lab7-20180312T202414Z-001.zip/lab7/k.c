
#include<stdio.h>


main()
{
int count , next_num,sum=0;
count = 1;
while (count <= 5)
{count += 1;
printf("Next number> ");
scanf("%d", &next_num);
sum+=next_num;
}
printf("%d numbers were added; \n", (count-1));
printf("their sum is %d.\n", sum);

}
