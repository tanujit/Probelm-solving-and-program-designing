//program to calculate the factorial of a number

#include<stdio.h> /*scanf printf defination*/                                            
#include<math.h> /*pow defination*/      
#define PI 3.141959265 //PI defination                                                     

double calculate_factorial(double); //function for calculation of factorial


void main()
{
double n; //input variable - number

printf("Enter n: "); //display instruction
scanf("%lf",&n);     //input the number                                

printf("factorial: %0.2f\n",calculate_factorial(n)); //display the factorial        

}


double calculate_factorial(double n)
{
double res=(2.0*n+1.0/3.0)*PI; // calculate res
double res2=sqrt(res);         // calculate res2

return pow(n,n)*exp(-n)*res2;             // calculate factorial
}
