//program to calculate the speed in mps and fps for crossing 1 mile in given time

#include<stdio.h>  //scanf printf defination 
double fps(int , double); //function defination for calculating speed in feet/sec
double mps(int , double); //function defination for calculating speed in  meter/sec


int main()
{

 int min;       //input variable- time in  minute
 double second; //input variable- time in second

printf("Enter the time: "); //Print instruction
scanf("%d%lf",&min,&second); //input the time in minute and second


printf("Speed in mps: %0.3f\n", mps(min, second) ); //Display the speed in meter/sec
printf("Speed in fps: %0.3f\n", fps(min, second) ); //Display the speed in feet/sec
return 0;
}

double mps(int min, double sec)
{
  sec+=(60.0*min);    //calculate total time in seconds
  return 5280/sec;    //calculate the speed in meter / second
}

double fps(int min, double sec)
{
  sec+=(60.0*min);   //calculate total time in seconds
  return (5280/3.28)/sec;  //calculate the speed in foot / second
}
