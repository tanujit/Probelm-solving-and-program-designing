#include<stdio.h>
void function1(int , int);
int funtion2(int , int);


int main()
{

 int first,
     second;

printf("Enter two numbers: ");
scanf("%d%d",&first,&second);

//function1(first,second);
printf("Sum: %d",function2(first,second));

return 0;
}

void function1(int first, int second)
{
printf("Sum: %d\n",(first+second));
}

int function2(int first , int second)
{
return (first+second);
}


