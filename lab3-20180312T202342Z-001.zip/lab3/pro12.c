
//function to calaculate the speed of sound in air at given temperature

#include<stdio.h>  // print scanf defination
#include<math.h>   //pow defination


double speeds(double); //function declaration to calculate the speed of sound


void instruct();         //print instructions


int main()
{

 double T;   //input variable - temperature of air 
 

instruct(); // function call to print instructions
scanf("%lf",&T); //input temperature


printf("Speed of sound: %f\n", speeds(T) ); //display the speed of sound

return 0;

}

double speeds(double t)
{
  return 1086.0*(sqrt((5.0*t+297.0)/247.0));// calculate the speed of sound
 }


void instruct()
{
printf("To calculate the speed of sound in air ");
printf("Enter the T: "); //instruction
}


