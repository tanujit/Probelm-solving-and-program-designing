//Program to calculate the constant acceleration from final and initial velocity

#include<stdio.h> //printf scanf defination

double acceleration(double , double); //function to calculate the constant acceleration
void instruct();                        //function to display the instruction


int main()
{

 double vi,   //input variable - initial  velocity
        vf,   //input variable - final  velocity
        time; //input variable - time
 

instruct();  //print instructions
scanf("%lf%lf",&vi,&vf);  //input initial and final velocity


printf("Acceleration: %f\n",  acceleration(vi,  vf) ); //siplay the acceleration
return 0;
}

double acceleration(double vi, double vf)
{
  vi=(vi*1609)/3600.0; //conversion of initial velocity to m/s
  vf=(vf*1609)/3600.0; //conversion of final velocity to m/s
  return (vf-vi)/3600.0; //calculate the constant acceleration
}


void instruct()
{
printf("To compute the constant acceleration\n");
printf("Enter the initial velocity(m/hr) and final velocity(m/hr) : ");  //instruction
}
