/*a program that takes a positive value with fractional part and rounds it up to 2 decimal place*/

#include<stdio.h> //printf scanf defination
#include<math.h>  //pow defination
double scale(double x, int n); //function to round off

int main()
{
double x1;   //input variable - x1
   int k1;   //input variable - k1

printf("Enter the number and value of n: "); //display instruction 
scanf("%lf%d",&x1,&k1); //input x1, k1

double res=scale(x1,k1);
double res2=res+0;
double res3= scale(res2,-k1);

printf("Result is:  %0.2f",res3); //display the rounded off value
 return 0;

}
double scale(double x, int n)
{
double scale_factor=pow(10, n); //calculate scale factor
return( x*scale_factor);        //calculate rounded off value
}




