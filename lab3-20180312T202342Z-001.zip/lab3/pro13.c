//program for calculating population after t years


#include<stdio.h>//scanf printf defination



double population(int);//calculate the population after T years


void instruct();//command to print the instructions


int main()//main function
{

 int T;//input variable- time period
 

instruct();//function call to print instructions
scanf("%d",&T);//input the year for which the population has to  be calculated.


printf("Predicted Gotham City population for %d (in thousands): %0.3f\n",T, population(T-1990) );//display the Gotham city population in thousands after implementation of function

return 15;

}

double population(int t)
{
  return 52.966+2.184*t;//calculate the population after t years
 }


void instruct()
{
printf("To calculate the population of gotham city ");
printf("Enter the year after 1990>  ");//instruction 
}


