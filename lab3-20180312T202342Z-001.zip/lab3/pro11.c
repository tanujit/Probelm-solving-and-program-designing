//program to calculate the gear ratio from maximum speed and minimum speed 


#include<stdio.h> //printf scanf defination
#include<math.h>  //pow defination


double speeds_ratio(double,double);  //function for calculating the gear ratio


void instruct(); // print instructions


int main()
{

 double m,  //input variable - minimum speed
        M;  //input variable - maximum speed
 

instruct(); //display instructions
scanf("%lf%lf",&M,&m); //input maximum speed and minimum speed


printf("The ratio between successive speeds of a six-speed gearbox with maximum speed %f rpm and minimum speed %f rpm is %f.\n", M,m,speeds_ratio(M,m) );   //display the gear ratio

return 0;

}

double speeds_ratio(double M,double m)
{
  return pow((M/m),(1.0/5.0)); //calculate the gear ratio
 }


void instruct()
{
printf("To calculate the gear ratio ");
printf("Enter the M and m: "); //instruction	
}


