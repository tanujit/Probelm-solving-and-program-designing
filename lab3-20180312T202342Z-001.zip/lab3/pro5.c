#include <stdio.h>
#include <math.h>

double scale(double , int );


int main()
{
double num_1;
int num_2;

printf("Enter a real number> ");
scanf("%lf", &num_1);
printf("Enter an integer> ");
scanf("%d", &num_2);

int z=scale(num_1,num_2);
int result = z+0.5;
printf("Result of call to function scale is %0.2f\n",scale(result, num_2));
return (0);
}




double scale(double x, int n)
{
double scale_factor1;

scale_factor1 = pow(10, -n);
return (x * scale_factor+0.5)*scale_factor1;
}
