//program to calculate the temperature at any given depth in both celcius and fahrenheit scales

#include<stdio.h> //printf scanf definaions

double celsius(double);   //function for calculating the the temperature in celcius
double fahrenheit(double);  //function for calculating the the temperature in fahrenheit

void instruct(); //print instructions


int main()
{

 double depth; //input variable- depth inside earth
 

instruct(); //print instructions
scanf("%lf",&depth);  //input depth

double cel=celsius(depth); //calculate temperature in celcius
printf("Celsius: %0.2f\n",  cel ); //display temperature in celsius
printf("Fahrenheit: %0.2f\n",  fahrenheit(cel) ); //calculate and display temprature in fahrenheit
return 0;
}

double celsius(double depth)
{
  

  return (10.0*depth+20.0); //calculate the temperature in celsius scale
}

double fahrenheit(double celsius)
{
  

  return (1.8*celsius+32.0);//calculate the temperature in fahrenheit scale
}

void instruct()
{
printf("To temperature at various depths\n");
printf("Enter the depth: "); //instructions
}
