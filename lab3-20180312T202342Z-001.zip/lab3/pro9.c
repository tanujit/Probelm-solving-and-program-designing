//program to calculate the total cost of making cylindrical cylinders

#define PI 3.14159265  //define PI
#include<stdio.h>      //scanf printf defination

double area_cost(double , double , double); //function for calculation of area
void instruct();     //function for displaying instruction


int main()
{

 double r,   //input variable-radius
        h,   //input variable-height
        cost;//input variable-cost per unit area
 

instruct();  //display the instruction
scanf("%lf%lf%lf",&r,&h,&cost); //input the radius,height, cost per unit area


printf("Cost: %0.2f\n",  area_cost(r,h,cost) ); //display the total cost
return 0;
}

double area_cost(double r, double h,double cost)
{
  

  return (((2*PI*r*h)+(PI*r*r))*cost); //calculate the total cost
}


void instruct()
{
printf("To compute the cost of making a cylinder\n");
printf("Enter the radius, height, cost: ");  //instruction
}
