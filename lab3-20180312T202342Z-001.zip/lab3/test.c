#include<stdio.h>
void main()
{
bool c;
c=true;
printf("%d",c);
}
