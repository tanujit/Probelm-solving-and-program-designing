#include<stdio.h>
void draw_h(void);
void draw_i(void);
void draw_m(void);
void draw_o(void);

int main(void)
{

draw_h();
draw_i();

printf("\n\n\n");

 draw_m();
 draw_o();
 draw_m();


}



void draw_h(void)
{
printf("*   *  \n");
printf("*   * \n");
printf("*****   \n");
printf("*   *  \n");
printf("*   * \n");
}

void draw_i(void)
{
printf("*******  \n");
printf("   *   \n");
printf("   *   \n");
printf("   *    \n");
printf("******* \n");
}

void draw_m(void)
{
printf("*    *  \n");
printf("**  ** \n");
printf("* ** * \n");
printf("*    *  \n");
printf("*    * \n");
}

void draw_o(void)
{
printf("    * * \n");
printf("  *     * \n");
printf(" *       *\n");
printf("  *     *  \n");
printf("    **    \n");
}
