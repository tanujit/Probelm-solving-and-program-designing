//calculation of monthly payment on basis of p,i,n
//anish nayak 1641017038
#include<stdio.h>                                                            //printf scanf defination
#include<math.h>                                                             //pow defination


double calculate_payment(double,double,double);     //function for calculating payment


void main()
{
double pr, // input variable- principal
       i,  // input variable- intrest rate per year
       n,  // input variable- number of payments
       price; // input variable- price of car

printf("Enter the Price, Downpayment, Intrest Rate, Number of months: ");   //Dsiplay instructions
scanf("%lf%lf%lf%lf",&price,&pr,&i,&n);                                     //input price, down paymnet , intrest, number pf months

printf("Monthly payment: %0.2f",calculate_payment((price-pr),i,n));            //display payment

}


double calculate_payment(double pr,double i,double n)
{
i/=1200.0;                                                                 //monthly intrest rate =rate /1200
return ((pr*i)/(1.0-pow((i+1.0),-n)));                                         //calculate payment
}
