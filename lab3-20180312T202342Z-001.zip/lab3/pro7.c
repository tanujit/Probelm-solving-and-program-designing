//Program to calculate the total cost of a given house after factoring cost of house , fuel cost and taxes

#include<stdio.h> //printf scanf definations

double cost(double , double, double); //function to calculate the total cost
void instruct();                      //function display the instructions


int main()
{

 double init_cost,  //input variable- inital cost of the house
        fuel_cost,  //input variable- fuel cost
        tax_rate;   //input variable- tax rate
 

instruct();     //display the instructions
scanf("%lf%lf%lf",&init_cost,&fuel_cost,&tax_rate); //input the initial cost,fuel cost and tax rate


printf("Cost after 5 years: %0.2f\n", cost(init_cost,fuel_cost, tax_rate) ); //display the total cost
return 0;
}

double cost(double init_cost,double fuel_cost,double tax_rate)
{
  
  return (init_cost+(fuel_cost*5)+(init_cost*tax_rate*5)); //calculate the total cost
}


void instruct()
{
printf("To compute the cost of the house\n");
printf("Enter the initial cost, fuel cost and tax rate: "); //instrucutions
}
