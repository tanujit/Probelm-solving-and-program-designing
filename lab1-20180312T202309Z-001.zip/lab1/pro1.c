/* Program that calculates the mileage reimbursement */
//Anish Nayak
//1641017038

#include<stdio.h>                                                           //scanf printf definition

int main(void)

{

double start_dist,                                                          //odometer start reading 
       end_dist,                                                            //odometer end reading 
	   diff,                                                                //diffence in odometer reading                     
	   cost_per_mile=0.35;                                                  //cost per mile 

printf("MILEAGE REIMBURSEMENT CALCULATOR");
printf("\nEnter the begining odometer reading=> ");
scanf("%lf",&start_dist);                                                   //input begining reading

printf("Enter the ending odometer reading=> ");                             //input ending reading
scanf("%lf",&end_dist);

diff=end_dist-start_dist;                                                   //diffence in odometer reading calculation   

printf("You traveled %f miles. At $0.35 per mile,",diff);
printf("\nYour reimbursement is $%0.2f.\n\n\n\n\n",diff*cost_per_mile);     //calculation and display of reimbursement    

return 0;
}


