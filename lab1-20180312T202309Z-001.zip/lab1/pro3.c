//program to calculate the temperature since power failure
//Anish Nayak
//1641017038


#include<stdio.h>                                            //scanf printf definitions

int main(void)
{
int hour,                                                    //time in hh
     min;                                                    //time in mm
 double final_temp,                                          //final temperature
        time;                                                //time taken in corrected format
        
printf("Enter the time since power failure in hh:mm : ");
scanf("%d%d",&hour,&min);                                    //input tine in hh:mm format

time=(double)hour+ min/60.0;                                 //time taken in corrected format calculation 
final_temp= ((4*time*time)/(time+2))-20;                     //final temperature calculation

printf("Current temperature: %0.1f\n",final_temp);          
}

