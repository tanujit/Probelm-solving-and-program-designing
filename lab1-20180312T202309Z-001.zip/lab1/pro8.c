//program to calculate the water saved
//Anish Nayak
//1641017038


/*
*algorithm
*input population
*calculate no of toilets
*calculate final and initial water consumption
*find difference
*display
*/

#include<stdio.h>                           //scanf printf definition

int main(void)
{
 int population;                            //population of city
 double no_toilets,                         //number of toilets
        initial_water_qty,                  //initial quantity of water used
	final_water_qty,                        //final quantity of water used
	diff;                                   //difference in quantity of water used
 
printf("Enter population: ");
scanf("%d",&population);                    //Input the population          

no_toilets=population/3;                    //number of toilets calculation     

initial_water_qty=no_toilets*15.0*14.0;     //initial quantity of water used calculation  

final_water_qty=no_toilets*2.0*14.0;        //final quantity of water used calculation  

diff=initial_water_qty- final_water_qty;    //difference in quantity of water used calculation  

printf("Water Saved: %f\n",diff);
}

