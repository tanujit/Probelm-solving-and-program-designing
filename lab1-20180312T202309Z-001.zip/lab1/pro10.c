/*Program to calculate slope, mid points , slope of perpendicular  , y intercept of a given line*/
//Anish Nayak
//1641017038


/*
algorithm:
*input x1,x2,y1,y2
*the slope if ound
*the slope  perpendicular bisector is found
*mid ppoints are calculated
*y intercept is calculated
*result displayed
*/


#include<stdio.h>                    //scanf , printf defination

int main(void)    
{
 double x1,                          //point x1
        x2,                          //point x2 
		y1,                          //point y1
		y2,                          //point y2
		slope,                       //slope of original line
		mid_x,                       //mid point x
	        mid_y,                       //mid point y
		slope_perpendicular,         //slope of perpendicular at midpint 
		k,                           //variable for perpendicular bisector
		Yin;                         //y intercept

printf("Enter X and Y of first point: ");     
scanf("%lf%lf",&x1,&y1);                                  //data input for point 1

printf("Enter X and Y of second point: ");
scanf("%lf%lf",&x2,&y2);                                  //data input for point 2

slope=(y2-y1)/(x2-x1);                                    // slope of line
printf("Slope: %f\n",slope);    

mid_x=(x2+x1)/2.0;                                        //mid point x calculation
mid_y=(y2+y1)/2.0;                                        //mid point y calculation
printf("Mid-Points: X: %f , X: %f \n",mid_x, mid_y);

slope_perpendicular=-1.0/slope;                           //slope of perpendicular calculation
printf("Slope of perpendicular bisector: %f \n",slope_perpendicular);
 
Yin=mid_y-(slope_perpendicular* mid_x);                   //y intercept calculation   
printf("The Y intercept of perpendicular bisector is %f \n",Yin);

k=(slope*mid_x)+Yin;                                      //equation
printf("Y= %f \n",k);
return 0;
}

