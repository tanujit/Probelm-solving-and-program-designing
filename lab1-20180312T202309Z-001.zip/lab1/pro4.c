//program to convert fahrenheit to celcius
//Anish Nayak
//1641017038


/*
*algorithm
*input in fahrenheit
*calculate in ceklsius
*display
*/

#include<stdio.h>                                      //scanf printf definitions

int main(void)
{
 double celsius,                                       //temperature in celsius
        fahrenheit;                                    //temperature in fahrenheit
        
printf("Enter the temperature in fahrenheit : ");
scanf("%lf",&fahrenheit);                              //input temperature in fahrenheit

celsius= (double)(fahrenheit-32)*(5.0/9.0);            //temperature in celsius calculation    

printf("Temperature in celsius: %0.2f\n",celsius);
}

