//Program to calculate pythogorean triples
//Anish Nayak
//1641017038


/*
algorithm
*m and n are taken as input
*side1 , side2 and hypoenuse calculated
*results displayed
*/

#include<stdio.h>                              //scanf printf definitions

int main(void)
{
 double side1,                                 //side of new triangle formed after calculating triples
        side2,                                 //side of new triangle formed after calculating triples
		hypotenuse,                            //hypotenuse of new triangle formed after calculating triples
		m,                                     //input variable m
		n;                                     //input variable n       

 
printf("Enter value of M: ");
scanf("%lf",&m);                               //input m

printf("Enter value of N: ");
scanf("%lf",&n);                               //input n

side1=m*m-n*n;                                  //side 1 calculation
side2=2*m*n;                                    //side 2 calculation
hypotenuse=m*m+n*n;                             //hypotenuse calculation


printf("Side1: %0.2f \n",side1);
printf("Side2: %0.2f \n",side2);
printf("Hypotenuse: %0.2f \n",hypotenuse);


return 0;
}

