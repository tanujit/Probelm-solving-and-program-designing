//program to calculate time for grass cutting
//Anish Nayak
//1641017038


/*
*algorithm
*input sides of house and yard
*calculate areas
*find the difference
*calculate speed
*/

#include<stdio.h>                                 //scanf printf definitions

int main(void)
{
 double length_house,                             //length of house
        width_house,                              //width of house
		lenth_yard,                               //length of yard
		width_yard,                               //width of yard
		area_yard,                                //area of yard
		area_house,                               //area of house
		time;                                     //time taken for grass cutting

printf("Enter length and width of house: ");
scanf("%lf%lf",&length_house,&width_house);       //input the length and width of the house

printf("Enter length and width of yard: ");       
scanf("%lf%lf",&lenth_yard,&width_yard);          //input the length and width of yard

area_yard=lenth_yard*width_yard;                  //yard area calculation
area_house=length_house*width_house;              //house area calculation


 time= ((area_yard-area_house)/2.0)/60;           //time taken for grass cutting calculation
 printf("Time: %0.2f \n",time);

}

