//program to calculate the btu
//Anish Nayak
//1641017038


/*
*input efficiency and quatity of fuel used
*calculate heat output
*display results
*/

#include<stdio.h>                               //scanf printf definition

int main(void)
{
 double fuel_qty,                               //quantity of fuel used                       
        efficiency,                             //efficiency of burning process
		btu_per_unit=5800000/42,                //btu per unit
		output_btu;                             //output btu
 
printf("Enter the quantity: ");
scanf("%lf",&fuel_qty);                         //input fuel quantity in gallons

printf("Enter the efficiency: ");
scanf("%lf",&efficiency);                       //input efficiency

output_btu=fuel_qty*efficiency*btu_per_unit;     //output btu calculation

printf("BTU: %0.2f\n",output_btu);
}

