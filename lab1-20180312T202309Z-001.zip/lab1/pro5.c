//program to calculate volume to be infused
//Anish Nayak
//1641017038


/*
*algorithm
*input volume and time
*calculate rate
*display results
*/

#include<stdio.h>                              //scanf printf definition

int main(void)
{
 double volume,                                //volume to be infused
        time,                                  //time taken for infusion
		rate;                                  //rate of infusion
		
printf("Volume to be infused: ");
scanf("%lf",&volume);                          //input vbti						

printf("Minutes over which to infuse : ");
scanf("%lf",&time);                            //input time

rate=(60.0/time)*volume;                       //rate of infusion calculation           

printf("VBTI= %0.2fml\n",volume);
printf("Rate: %0.2fml/hr\n",rate);             
}

