//program to calculate the required marks
//Anish Nayak
//1641017038


/*
*algorithm
*input grade, required marks, current marks
*find difference
*calculate the marks
*display
*/

#include<stdio.h>                                                               //scanf printf definition

int main(void)
{
 double current_marks,                                                          //current marks of the student                                
        required_marks,                                                         //marks the student needs   
		percentage,                                                             //percentage of marks difference
		score;                                                                  //marks the student needs to score to get the desired marks
 char grade;                                                                    //grade
 
printf("Enter desired grade> ");
scanf("%c",&grade);                                                             //input grade
 
printf("Enter minimum average required: ");
scanf("%lf",&required_marks);                                                   //input required marks

printf("Enter current average in course: ");
scanf("%lf",&current_marks);                                                    //input the current marks

printf("Enter how much the final counts as percentage: ");
scanf("%lf",&percentage);                                                       //input the percentage that difference in marks represent

score= current_marks+((required_marks-current_marks)*(100/percentage));         //marks calculation

printf("You need a score of %0.2f on the final to get a %c.\n",score,grade);
}

