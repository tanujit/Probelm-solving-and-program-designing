//program to calculate the acceleration and time during takeoff
//Anish Nayak
//1641017038


/*
*input velocity and distance
*convert speed to m/s
*calculate acceleration
*compute time
*display 
*/

#include<stdio.h>                  //printf scanf definition

int main(void)
{
 double velocity_final,            //final velocity           
        velocity_initial=0,        //initial velocity
        acceleration,              //acceleration
        distance,                  //distance for takeoff
        time;                      //time taken by plane fortakeoff
 
printf("Enter Launch Velocity (Km/Hr): ");                                    
scanf("%lf",&velocity_final);              //input velocity
velocity_final=velocity_final*(5.0/18.0);  //conversion to m/s

printf("Enter Launch Distance (metres): ");
scanf("%lf",&distance);                    //input distance

acceleration= (velocity_final*velocity_final - velocity_initial*velocity_initial)/(2*distance);  //acceleration calculation

time= velocity_final/acceleration;                                                               //time calculation

printf("Acceleration: %0.2f m/s^2\n",acceleration);  //display results
printf("Time: %0.2f secs\n",time);                   //display results

return 0;
}

