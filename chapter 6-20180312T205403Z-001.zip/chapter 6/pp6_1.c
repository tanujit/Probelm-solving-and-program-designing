#include<stdio.h>
void nobi(int *x,int *y, int *z,int *n);
int main()
{
int amt,a,b,c;
printf("enter the amount desired as a multiple of 10 dollars:\n");
scanf("%d",&amt);
nobi(&a,&b,&c,&amt);
printf("no of 50s is %d \nNo of 20 is %d\nNo of 10s is %d .\n",a,b,c);
}
void nobi(int *x,int *y,int *z,int *n)
{
*x=(*n)/50;
*n=(*n)%50;
*y=(*n)/20;
*n=(*n)%20;
*z=(*n)/10;
}

