#include<stdio.h>
#define RHO 1.23
double compute_drag_force(double CD,double A,int vel);

int 
main(void)
{
	double CD, 		
	       A,  		
	       drag_force;	
	int vel;		

	
	printf("Enter the drag coefficient(between 0.2 to 0.5)=>\n");
	scanf("%lf",&CD);
	printf("\nEnter the projected area in meter square=>\n");
	scanf("%lf",&A);

	
	printf("\nVelocity%10cDrag Force\n------------------------------\n",' ');
	
	for(vel=0;vel<=40;vel+=5)
	{
		drag_force=compute_drag_force(CD,A,vel);		
		printf("%d%15c%.2f\n",vel,' ',drag_force);
	}
	return (0);
}


double compute_drag_force(double CD,double A,int vel)
{
	double drag_force;
	drag_force=1.0/2*(CD*A*RHO*vel*vel);
	return drag_force;
}
