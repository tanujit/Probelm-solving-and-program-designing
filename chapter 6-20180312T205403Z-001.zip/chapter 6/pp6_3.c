#include <stdio.h>

void change( int *d, int *q, int *di, int *n, int *p, int paid, int due );

int main(void)
{
    
    int paid;
    int due;
    int dollars;
    int quarters;
    int dimes;
    int nickels;
    int pennies;

    int *d;
    int *q;
    int *di;
    int *n;
    int *p;

    printf( "Enter amount due: \n" );
    scanf( "%d", &due );

    printf( "Enter amount paid: \n" );
    scanf( "%d", &paid );

    change( &dollars, &quarters, &dimes, &nickels, &pennies, paid, due );

    printf( "Dollars = %d\nquarters = %d\ndimes =%d\nnickels = %d\npennies = %d", dollars, quarters, dimes, nickels, pennies );

    return 0;
}

void change( int *d, int *q, int *di, int *n, int *p, int paid, int due )
{
   int dm;
   int qm;
   int dim;
   int nm;
   int pm;
   int modu;
   int modu2;
   int modu3;
   int total;
   int penniestotal;

   total = due - paid;

   penniestotal = total * 100;

   dm = penniestotal / 100;
   modu = penniestotal % 100;
   qm = modu / 25;
   modu2 = modu % 25;
   dim = modu2 / 10;
   modu3 = modu2 % 10;
   nm = modu3 / 5;
   pm = modu3 % 5;
}
