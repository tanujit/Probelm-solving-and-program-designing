#include <stdio.h>
void function(double n,double *NGPtr){
   /* double n;
    nPtr=&n;
    double NG;*/
    double LG=1.0;
     //  printf("Enter guess\n");
   // scanf("%lf",&LG);
    do
{
       *NGPtr=(0.5*(LG+(n/LG)));
        LG=*NGPtr;
    }while((*NGPtr-LG)>.005);
}
int main(){
    double NGP;
    double n;

    printf("Enter number\n");
    scanf("%lf",&n);

function(n,&NGP);

    printf("The approximate root of the function is %f",NGP);
return(0);
}               
