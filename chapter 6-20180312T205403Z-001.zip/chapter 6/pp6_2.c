#include <stdio.h>
#define MINUTE 60      /* number of minutes in an hour*/
#define M_LITER 1000
#define SENTINEL 5

int get_problem(void);                     
void get_rate_drop_factor(double *, double *);
void get_kg_rate_conc(double *, double *, double *);
void get_units_conc(double *, double *);
double fig_drops_min(double, double);
double fig_ml_hr(double);
double by_weight(double, double, double);
double by_units(double, double);

int
main(void)
  {   
	   int value;          /* option choosen*/   
	double answer;         /* return value of functions*/   
	double ml_hour;        /* rate in ml/hr*/   		
	double drops_ml;       /* tubing factor in drops/ml*/   
	double mg_kg_hour;     /* rate in mg/kg/hr*/   
	double pat_weight;     /* patient's weight in kg*/   
	double mg_ml;          /* concentration in mg/ml*/   
	double units_hour;     /* rate in units/hr*/   
	double units_ml;       /* concentration in units/ml*/   
	double num_hours;      /* number of hours for 1 L to be delivered*/

        value = get_problem();
        while( value != SENTINEL )   
	     {      
		switch(value)      
		   {         
			case 1: get_rate_drop_factor(&ml_hour, &drops_ml);                 
				answer = fig_drops_min(ml_hour, drops_ml);                 
				printf("\n");                 
				printf("The drop rate per minute is %.0f\n\n", answer);                 
				break;         
			case 2: printf("Enter number of hours => ");                 
				scanf("%lf", &num_hours);                 
				printf("\n");                 
				answer = fig_ml_hr(num_hours);                 
				printf("The rate in milliliters per hour is %.0f\n\n", answer);           
				break;
			case 3: get_kg_rate_conc(&mg_kg_hour, &pat_weight, &mg_ml);
                 		answer = by_weight(mg_kg_hour, pat_weight, mg_ml);                 
				printf("\n");                 
				printf("The rate in milliliters per hour is %.0f\n\n", answer);                 
				break;
         		case 4: get_units_conc(&units_hour, &units_ml);                 
				answer = by_units(units_hour, units_ml);                 
				printf("\n");                 
				printf("The rate in milliliters per hour is %.0f\n\n", answer);                 
				break;
			default: printf("Wrong input.\n");
		   }
		value = get_problem();
	     }            
   }

/* function displays menu and gets user's input*/
int 
get_problem(void)
   {
	int menu_number;   
	printf("Enter the number of the problem you wish to solve.\n\n");   
	printf("GIVEN A MEDICAL ORDER IN\t\t\tCALCULATE RATE IN\n\n");   
	printf("[1] ml/hr & tubing drop factor\t\t\tdrops/min\n");   
	printf("[2] 1 L for n hr\t\t\t\tml/hr\n");   
	printf("[3] mg/kg/hr & concentration in mg/ml\t\tml/hr\n");   
	printf("[4] units/hr & concentration in units/ml\tml/hr\n");   
	printf("[5] Quit\n\n");
	printf("Problem => ");   
	scanf("%d", &menu_number);
	return menu_number;
   }

/* function prompts the user to enter rate and tubing's drop factor then returns  * values through output parameters */
void 
get_rate_drop_factor(double *ml_hour, double *drops_ml)
   {   
	printf("Enter rate in ml/hr => ");   
	scanf("%lf", ml_hour);   
	printf("\n");   
	printf("Enter tubing's drop factor(drops/ml) => ");   
	scanf("%lf", drops_ml);   printf("\n\n");
   }

/* function prompts for rate, patient's weight, and concentration then returns  * values through output parameters */
void 
get_kg_rate_conc(double *mg_kg_hour, double *pat_weight, double *mg_ml)
   {   
	printf("Enter rate in mg/kg/hr => ");   
	scanf("%lf", mg_kg_hour);   
	printf("\n");   printf("Enter patient weight in kg => ");   
	scanf("%lf", pat_weight);   
	printf("\n");   
	printf("Enter concentration in mg/ml => ");   
	scanf("%lf", mg_ml);   
	printf("\n\n");
   }

/* function prompts for rate and concentration then returns  * values through output parameters */
void 
get_units_conc(double *units_hour, double *units_ml)
   {   
	printf("Enter rate in units/hr => ");   
	scanf("%lf", units_hour);   
	printf("\n");   
	printf("Enter concentration in  units/ml => ");   
	scanf("%lf", units_ml);   printf("\n\n");
   }

/* function takes as input rate and concentration then returns as its value the result of  * dividing their product by MINUTE */
double 
fig_drops_min(double ml_hour, double drops_ml)
   {   
	return ml_hour * drops_ml / (double)MINUTE;
   }


/* function takes as input num_hours and returns as its value the quotient of 1000  * and  num_hours */
double 
fig_ml_hr(double num_hours)
   {     
	return M_LITER / num_hours;
   }

/* function takes 3 inputs and returns as its value the product of rate and patient's * weight divided by concentration */
double 
by_weight(double mg_kg_hr, double pat_weight, double mg_ml)
   {   
	return mg_kg_hr * pat_weight / mg_ml;
   }

/* function takes 2 inputs and returns as its value the quotient of units_hr and units_ml.*/ 
double by_units(double units_hour, double units_ml)
   {   
	return units_hour / units_ml;
   }
