#include<stdio.h>
#include<math.h>
#define flat_rate 7.99
#define hrly_or_parly_rate 1.99
void charges(double *day,double *yr,double *ID,double *hr_used,double *chrg_p_hr,double *avg_cost);
FILE *inp;
FILE *outp;
int 
main(void)
{
	double day,yr,ID,hr_used,chrg_p_hr,avg_cost,extra_hr;
	inp=fopen("usage.txt","r");
	outp=fopen("charges.txt","w");
	charges(&day,&yr,&ID,&hr_used,&chrg_p_hr,&avg_cost);
	fclose(inp);
	fclose(outp);
	return(0);
}
void charges(double *day,double *yr,double *ID,double *hr_used,double *chrg_p_hr,double *avg_cost)
{	
	int i;
	double extra_hr;
	for(i=1;i<=4;i++)
	{
		if (i==1)
		{
			fscanf(inp,"%lf %lf",&*day,&*yr);
			fprintf(outp,"Charges for %0.0f/ %0.0f\n\n",*day,*yr);
			fprintf(outp,"Customer%10lfHours used%10lfCharge/hour%10lfAverage cost\n",*hr_used,*chrg_p_hr,*avg_cost);
		}
		else
		{
			fscanf(inp,"%lf %lf",&*ID,&*hr_used);
			if (*hr_used<=10)
			{
				*chrg_p_hr=flat_rate;
				*avg_cost=*chrg_p_hr/ *hr_used;
			}
			else
			{
				extra_hr=ceil(*hr_used)-10;
				*chrg_p_hr=flat_rate+extra_hr*hrly_or_parly_rate;
				*avg_cost=*chrg_p_hr/ *hr_used;
			}
			fprintf(outp,"%0.0f%15c  %0.1f%15c %0.2f%15c %.2f\n",*ID,' ',*hr_used,' ',*chrg_p_hr,' ',*avg_cost);
		}	
	}	
}
