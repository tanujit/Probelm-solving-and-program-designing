#include<stdio.h>

double calc_K();
double  calc_A();
void calc_T1(double *K,double *a,double *t2,double *t1,double *h,double *x);
double  calc_T2();
double  calc_X();
double  calc_H();

int  main(void)
{
 double K,a,t2,t1,h,x;
calc_T1(&K,&a,&t2,&t1,&h,&x);
printf("Temperature on other side (K) >> %.2f \n ",t1);
return 0;
}

double  calc_H()
  { double H;
    printf("Rate of heat transfer (watts) >> \n");
    scanf("%lf",&H);
    return H;
  }
  
double  calc_K()
  { double k;
    printf("Coefficient 0f thermal conductivity (W/m-K) >> \n");
    scanf("%lf",&k);
    return k;
  }
  
double  calc_A()
  {
    double A;
    printf("Cross-sectional area of conductor (m^2) >> \n");
    scanf("%lf",&A);
    return A;
  }
  
double  calc_T2()
  {
    double T2;
    printf("Temperature on one side (K) >> \n");
    scanf("%lf",&T2);
    return T2;
  }
  
void calc_T1(double *K,double *a,double *t2,double *t1,double *h,double *x)
  { 
    double T2,H,k,A,T1,X;
    printf("Final Result is here \n");
    *h=calc_H();
    *K=calc_K();
    *a=calc_A();
    *t2=calc_T2();
    *x=calc_X();
        *t1= -(((*h)*(*x))/((*K)*(*a))-(*t2));
   }
   
double calc_X()
  {
    double x;
    printf("Thickness of conductor (m) >> \n");
    scanf("%lf",&x);
    return  x;
  } 



