#include<stdio.h>
#include<math.h>
int
main(void)
{
int n;double sum=0.0;
printf("enter the size:n");
scanf("%d",&n);
int a[n];

printf("enter the n elements\n");
int i;
for(i=1;i<=n;i++)
{
scanf("%d",&a[i]);
sum+=a[i];
}
int min=a[1];

for(i=1;i<=n;i++)
{
if(a[i]<min)
min=a[i];
}
printf("the minimum number is %d\n",min);
int max=a[1];

for(i=1;i<=n;i++)
{
if(a[i]>max)
max=a[i];
}
printf("the maximum number is %d\n",max);
printf("the sum is %lf",sum);
double av=(sum/n);
printf("the average is %f\n",av);
double ss=pow(sum,2);
double t=ss/n;
double as=pow(av,2);
double sd=t-as;
double standard_deviation=sqrt(sd);
printf("the standard deviatuin is %f\n",standard_deviation);
}


