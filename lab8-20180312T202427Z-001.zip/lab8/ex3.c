#include<stdio.h>
main()
{int i,j,k,n=5,m=4;

for(i = 1;i <=n;++i)

 {
  for(j = 1;j <= i;++j)

	{
		printf("%d ",j);
	}
  printf("\n");
  }

for(;i >=1;i--)

 {
  for(j = 1;j<=i ;++j)

	{
		printf("%d ",j);
	}

   printf("\n"); 	
  }



}
