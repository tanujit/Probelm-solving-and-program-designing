#include<stdio.h>
main()
{
int n=15435,a,z,sum=0;
z=n;
char c;

while(n!=0)
{
a=(n%10);
c=(char)a+'0';
printf("char= %c \n",c);

printf("ascii= %d \n",(int)c);
sum+=a;
n/=10;



} 

printf("Sum= %d\n",sum);

/*
if(sum%9==0)
printf("Divisible by 9\n");
else
printf("Not divisible by 9\n");
*/
}
