#include<stdio.h>
#include<math.h>
main()
{
double b,a,c,principal=1000.0,intrest=9.0/1200.0,payment,time=6.0;
//payment= (intrest*principal)/(1.0-(pow((1.0+intrest),-time)));





payment= (intrest*principal)/(1.0-(pow((1.0+intrest),-time)));	

printf("Intrest		Payment		Principal\n");
int i;
//while(principal>=0)
for( i=0;i<6;i++)
{
a=intrest*principal;
 
//printf("Payment= %f\n",payment);
b=payment-a;
//printf("b= %f\n",b);
//c=principal-b;
principal=principal-b;
//printf("princ= %f\n",principal);

printf("%0.2f		%0.2f		%0.2f\n",a,b,principal);
//break;

} 

//printf("Sum= %d\n",sum);


}
