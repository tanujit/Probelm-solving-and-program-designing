#include<stdio.h>
main()
{int i,j,n=5,m=4;

for(i = 1;i <= n;++i)
 {for(j = 0;j < i;++j)

{
printf("*");
}
printf("\n");


}

printf("\n\n\n\n");


for(i = n;i>0;--i)
 {for(j = m;j >0;--j)

{
printf("*");
}
printf("\n");


}

}
