#include<stdio.h>
main()
{int i,j,k,n=5,m=4;

for(i = 0;i <3;++i)

 {printf("Outer %4d\n",i);
  for(j = 0;j < i;++j)

	{
		printf("Inner%3d%3d\n", i, j);
	}

    for(k=2;k >0;--k)
  	{
		printf("Inner%3d%3d\n", i, k);
	}	
}
}
