#include<stdio.h>
main()
{
double sum=0;
int n ,i,z;
printf("Enter n: ");
scanf("%d",&n);
if(n>0)
{

  for (i=0;i<n;i++)
   {
    printf("Enter number: ");
    scanf("%d",&z);
    sum+=z;
   }

  printf("Average: %0.2f",(sum/n));

}
else
{
  printf("Cannot Find Average");
}


}
