#include<stdio.h>
main()
{
double water=12.0;
int x=12;
int z=(water==x);

printf("%d \n",z);


}

