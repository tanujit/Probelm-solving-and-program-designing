#include<stdio.h>
main()
{
int item ,product=1;
printf("Enter the item: ");
scanf("%d",&item);
if(item!=0)
{product*=item;
 printf("Product: %d \n",product);
}
else
{
  printf("Product: %d \n",product);
}


int x,y;
printf("Enter x and y : ");
scanf("%d%d",&x,&y);
if((x-y)>0)
printf("Absolute Difference: %d \n",(x-y));
else
printf("Absolute Difference: %d \n",(y-x));

int x1,zero_count=0,minus_sum=0,plus_sum=0;
printf("Enter x: ");
scanf("%d",&x1);
if(x1==0)
{
 zero_count++;
 printf("Zero count: %d \n",zero_count);
}
else if(x1>0)
{
 plus_sum+=x1;
 printf("plus sum: %d \n",plus_sum);
}

else

{
 minus_sum+=x1;
 printf("minus_sum:  %d \n",minus_sum);

}


}
