#include<stdio.h>
main()
{
int age;
printf("Enter the age: ");
scanf("%d",&age);
int x=(age<=21&&age>=18);
printf("%d \n",x);

double water;
printf("Enter the water level: ");
scanf("%lf",&water);
x=(water<=1.5&&water>=0.1);
printf("%d \n",x);

int year;
printf("Enter the year: ");
scanf("%d",&year);
x=(year%4==0);
printf("%d \n",x);

}

