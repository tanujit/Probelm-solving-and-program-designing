#include<stdio.h>
main()
{
char t;
double sum=0;
int n ,i,z;
printf("Enter type: ");
scanf("%c",&t);
printf("t: %c \n",t);


if(t=='c'||t=='C')
{
 printf("Enter radius: ");
 double r;
 scanf("%lf",&r);
 printf(" AREA: %f\n",(3.14*r*r));
 
  
}

else if(t=='s'||t=='S')
{
 printf("Enter side: ");
 double s;
 scanf("%lf",&s);
 printf(" AREA: %f\n",(s*s));
 
  
}
else
{
  printf("Wrong Input\n");
}


}
