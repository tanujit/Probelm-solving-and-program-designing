#include<stdio.h>
main()
{
char color;


printf("Enter Color: ");
scanf("%c",&color);


switch (color) 
{ 
case 'R':
case 'r':
  printf("red\n");
  break;
case 'B':
case 'b':
  printf("blue\n");
  break;
case 'Y':
case 'y':
  printf("yellow\n");
  break;
default:
  printf("wrong input.\n");
}
}
