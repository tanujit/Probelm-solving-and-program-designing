#include<stdio.h>
main()
{

int n ;
printf("Enter number: ");
scanf("%d",&n);


if(n>0)
{
 printf("Positive number \n ");
  
}

if(n<0)
{
 printf("Negative number \n ");
  
}

if(n==0)
{
 printf("Zero \n ");
  
}




}
