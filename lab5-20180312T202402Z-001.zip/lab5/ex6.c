#include<stdio.h>
main()
{
double n ;
printf("Enter blood pressure: ");
scanf("%lf",&n);


if(n<=120.0)
{
 printf("Normal\n");
  
}

else if(n<=139.0)
{
 printf("Pre- Hypertension\n");  
}

else 
{
 printf("Hypertension\n");  
}
}
