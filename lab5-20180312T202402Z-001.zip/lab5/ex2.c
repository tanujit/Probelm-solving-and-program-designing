#include<stdio.h>
main()
{
int n ;
printf("Enter number: ");
scanf("%d",&n);

if(n>=0)
{
if(n>0)
{
 printf("Positive number \n ");
}
else
{
 printf("Zero \n ");
}
}
else
{
 printf("Negative Number \n ");
}
}
