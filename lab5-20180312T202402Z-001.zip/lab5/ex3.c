#include<stdio.h>
main()
{

int n ;
printf("Enter number: ");
scanf("%d",&n);


if(n>0)
{
 printf("Positive number \n ");
  
}

else if(n<0)
{
 printf("Negative number \n ");
  
}

else
{
 printf("Zero \n ");
  
}




}
