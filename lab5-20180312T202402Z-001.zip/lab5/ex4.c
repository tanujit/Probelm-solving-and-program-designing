#include<stdio.h>
main()
{

int age;
char martial_status,person ;
printf("Enter marital status,person, age: ");
scanf("%c %c %d",&martial_status,&person,&age);


if((martial_status=='s'||martial_status=='S')&&(person=='y'||person=='Y')&&(age<=26&&age>=18))
{
 printf("Person is eligible for voting \n ");
}

else if((martial_status=='m'||martial_status=='M')&&(person=='o'||person=='O')&&(age>=60))
{
 printf("Person is senior citizen \n ");
}

else
{
 printf("Invalid Input \n ");
  
}




}
