#include<stdio.h>
main()
{
double n ;
printf("Enter grade point: ");
scanf("%lf",&n);


if(n<=0.99&&n>=0.0)
{
 printf("Failed semster-- registration suspended\n");
  
}

else if(n<=1.99)
{
 printf("On probation for next semester\n");  
}

else if(n<=2.99)
{
 printf("No Message\n");  
}

else if(n<=3.49)
{
 printf("Dean’s list for semester\n");  
}

else 
{
 printf("Highest honors for semester\n");  
}
}
