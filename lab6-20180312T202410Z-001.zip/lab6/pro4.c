#include<stdio.h>
main()
{
char color;


printf("Enter Color: ");
scanf(" %c",&color);


switch (color) 
{ 
case 'o':
case 'O':
  printf("orange	ammonia\n");
  break;
case 'B':
case 'b':
  printf("brown		carbon monoxide\n");
  break;
case 'Y':
case 'y':
  printf("yellow 	hydrogen\n");
  break;
case 'g':
case 'G':
  printf("green 	oxygen\n");
  break;
default:
  printf("wrong input.\n");
}
}
