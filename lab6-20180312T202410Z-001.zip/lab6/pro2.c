#include<stdio.h>
main()
{
double wt_lb ,ht_in,bmi;
printf("Enter weight: ");
scanf("%lf",&wt_lb);

printf("Enter height: ");
scanf("%lf",&ht_in);

bmi=(703.0*wt_lb)/(ht_in*ht_in);

if(bmi<=18.5)
{
 printf("Underweight\n");
  
}

else if(bmi<=24.9)
{
 printf("Normal\n");  
}


else if(bmi<=29.9)
{
 printf("Overweight\n");  
}

else 
{
 printf("Obese\n");  
}
}
