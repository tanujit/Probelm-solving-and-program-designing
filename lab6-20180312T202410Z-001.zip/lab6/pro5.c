#include<stdio.h>

main()
{
double richter;
printf("Enter richter scale number: ");
scanf("%lf",&richter);


if(richter<5.0)
{
 printf("Little or no damage\n");
  
}

else if(richter<5.5)
{
 printf("Some damage\n");  
}


else if(richter<6.5)
{
 printf("Serious damage: walls may crack or fall\n");  
}

else if(richter<7.5)
{
 printf("Disaster: houses and buildings may collapse\n");  
}


else 
{
 printf("Catastrophe: most buildings destroyed\n");  
}


getch();}
