#include<stdio.h>
main()
{
double x,y;
printf("Enter x and y: ");
scanf("%lf%lf",&x,&y);




 if(y==0&&x==0)
printf("Origin\n");


else if(x==0)
{
 printf("Y axis\n");
}

else if(y==0)
printf("X axis\n");

else if(x>0)
{
 if(y>0)
 printf("Quadrant 1\n");
 else
 printf("Quadrant 4\n");
  
}


else if(x<0)
{
if(y>0)
 printf("Quadrant 2\n");
 else
 printf("Quadrant 3\n");
  
}



}
