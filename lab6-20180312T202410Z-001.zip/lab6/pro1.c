#include<stdio.h>

double greater_100(double);
double smaller_100(double);

void main()
{
double amount;
char t;


//printf("Enter the sales amount: ");
scanf("%lf",&amount);

if(amount>=100)
  greater_100(amount);
else
  smaller_100(amount);
}



double greater_100(double amount)
{
double discount=0.12*amount,tax,total;
char teacher;
//printf("Enter if the person is a music teacher(y/n): ");
scanf(" %c",&teacher);

if(teacher=='Y'||teacher=='y')
discount=0.1*amount;
/*else
{printf("Invalid Input\n");
 return;
}
*/

total=amount-discount;
tax=total*0.05;

printf("Total purchases           $%0.2f\n",amount);
printf("Teachers discount         $%f   \n",discount);
printf("Discounted total          $%0.2f\n",total);
printf("Sales tax                 $%0.2f\n",tax);
printf("Total                     $%0.2f\n",(total+tax));

}

double smaller_100(double total)
{
double tax=total*0.05;
printf("Total purchases           $%0.2f\n",total);
printf("Sales tax                 $%0.2f\n",tax);
printf("Total                     $%0.2f\n",(total+tax));

}


