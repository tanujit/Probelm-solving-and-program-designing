#include<stdio.h>
main()
{
double diff,angle;
printf("Enter angle ");
scanf("%lf",&angle);


if(angle>=0.0&&angle<180.0)
{
 if(angle<=90.0)
 {
 printf("Turn north\n");	
 diff=angle;
 printf("Turn east\n"); 	
 printf("%f\n",diff); 
 }
  else
  {
  printf("Turn south\n");	
 diff=180-angle;	
 printf("Turn east\n");
 printf("%f\n",diff); 
  }
}

else if(angle>=180.0&&angle<=360.0)
{
 if(angle<=270.0)
 {
 printf("Turn South\n");	
 printf("Turn west\n");
 diff=angle-180.0;	
 printf("%f\n",diff); 
 }
  else
  {
 printf("Turn North\n");	
 printf("Turn west\n");
 diff=angle-270.0;	
 printf("%f\n",diff); 
  }  
}
else 
{
 printf("Wrong Input\n");  
}

}
