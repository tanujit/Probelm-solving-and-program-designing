#include<stdio.h>
int main()
{
int d,m,y;
printf("Enter date month year:  ");
scanf("%d%d&d",&d,&m,&y);

if(d<0||d>31)
return 0;
if(m<0||m>12)
return 0;

int feb;
if(y%4==0)
 feb=29;
if (y%4!=0)
 feb=28;
printf("feb: %d ",feb); 
 

int day=0;
if(m<=1)
{
  printf(": %d",day);
}
else if(m<=2)
{
	day=31+d;
	printf(": %d",day);
	
}
else if(m<=3)
{
	day=31+feb+d;
	printf(": %d",day);
	
}
else if(m<=4)
{
	day=31+feb+31+d;
	printf(": %d",day);
	
}
else if(m<=5)
{
	day=31+feb+31+30+d;
	printf(": %d",day);
	
}else if(m<=6)
{
	day=31+feb+31+30+31+d;
	printf(": %d",day);
	
}else if(m<=7)
{
	day=31+feb+31+30+31+30+d;
	printf(": %d",day);
	
}else if(m<=8)
{
	day=31+feb+31+30+31+30+31+d;
	printf(": %d",day);
	
}else if(m<=9)
{
	day=31+feb+31+30+31+30+31+31+d;
	printf(": %d",day);
	
}else if(m<=10)
{
	day=31+feb+31+30+31+30+31+30+d;
	printf(": %d",day);
	
}else if(m<=11)
{
	day=31+feb+31+30+31+30+31+30+31+d;
	printf(": %d",day);
	
}else if(m<=12)
{
	day=31+feb+31+30+31+30+31+30+31+30+d;
	printf(": %d",day);
	
}
else 
{
 printf("Wrong Input\n");  
}
return 0;
}
