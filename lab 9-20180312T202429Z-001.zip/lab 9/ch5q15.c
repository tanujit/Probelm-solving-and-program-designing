#include<stdio.h>
#include<math.h>
double fx(double s);
double 

int
main(void)
{
double a,b;
a=0;
b=3.14159;

double h=(b-a)/2;
int n;
printf("enter the no of blocks");
scanf("%d",&n);
double z,sum=0;
for(i=1;i<=n-1;i++)
{
z=fx(i);
sum+=z;
}

double s=fx(a);
double t=fx(b);

double T=(h/2)*(s+t+(2*sum));
printf("the approximate trapezoidal area is %lf\n",T);
return 0;
}

double fx(double s)
{
return(s*s*(sin(s)));
}





