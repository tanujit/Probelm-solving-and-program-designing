#include<stdio.h>
main()
{
double qty,temp, iv,fv,vi;

printf("Quantity of carbon dioxide (moles)> ");
scanf("%lf",&qty);
printf("Temperature (kelvin)> ");
scanf("%lf",&temp);
printf("Initial volume (milliliters)> ");
scanf("%lf",&iv);
printf("Final volume (milliliters)> ");
scanf("%lf",&fv);
printf("Volume increment (milliliters)> ");
scanf("%lf",&vi);
//double v=450;
/*double x=(3.592*0.02*0.02)/(400.0*400.0);
double y=0.02*8.314*300;
double z=y/(400-(0.0427*0.02));
double p=z-x;*/
double p,v;

printf("Volume		Pressure\n");
for(v=iv;v<=600;v+=vi)
{p=((qty*8.314*temp)/(v-(qty*0.0427)))-((3.592*qty*qty)/(v*v));
//p=(8.314*qty*temp)/v;

printf("%0.2f		%0.2f\n",v,(p));
}
}
