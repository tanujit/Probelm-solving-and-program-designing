#include<math.h>
#include<stdio.h>
double fx(double,double,double);
double f1x(double,double);


main()

{
int i=0;
double x,y,z,n,c,xj,xj1;
printf("Enter the n and c: ");
scanf("%lf%lf",&n,&c);
 xj=c/2.0;
while(i<=100)
{   
        
   
        y=fx(xj,n,c);
        z=f1x(xj,n);
	xj1=xj-(y/z);
	printf("iteration: %d          %f\n",i,xj1);
        xj=xj1;
        i++;
}





}

double fx(double x,double n,double c)
{return pow(x,n)-c;}

double f1x(double x,double n)
{
return (n*pow(x,(n-1)));
}
