#include<stdio.h>
#include<math.h>
int main(void)
{
	double q,n=0.014,a,r,s=0.0015,d,w=15.0;
	printf("Enter your initial guess for the channel depth when the flow is 1000.0000 cubic feet per second \n");
	printf("Enter guess> ");
	scanf("%lf",&d);
	do
	{
		r=(d*w)/(2.0*d+w);
		a=w*d;
		float r1=pow(r,(2.0/3.0));
		float s1=pow(s,(1.0/2.0));
		q=(1.486/n)*a*r1*s1;
		float diff=1000.0-q;
		float e=diff/10.0;
		printf("Depth: %0.4lf Flow: %0.4lf cfs Target: 1000.0000 cfs Difference: %0.4lf Error: %0.4lf percent \n",d,q,diff,e);
		printf("Enter guess> ");
		scanf("%lf",&d);
	}
	while(q!=1000.0);
	return(0);			
}
